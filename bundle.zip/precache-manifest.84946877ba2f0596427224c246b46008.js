self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "36e4800dd49bf0e76a8f970c530caeaf",
    "url": "/index.html"
  },
  {
    "revision": "033bb625f4e917e3fcbe",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "721f67583e87e0def1d5",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "033bb625f4e917e3fcbe",
    "url": "/static/js/2.7d6d4d99.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.7d6d4d99.chunk.js.LICENSE.txt"
  },
  {
    "revision": "721f67583e87e0def1d5",
    "url": "/static/js/main.2acde381.chunk.js"
  },
  {
    "revision": "d2aa4dcc9e92c2ee2b9b",
    "url": "/static/js/runtime-main.a563111f.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);