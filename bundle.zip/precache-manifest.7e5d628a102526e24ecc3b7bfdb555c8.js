self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "383befdee42d152fcc5af4efeedfa69e",
    "url": "/index.html"
  },
  {
    "revision": "504e68e560224d31e435",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "4a923d960294146bf0e2",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "504e68e560224d31e435",
    "url": "/static/js/2.fee60c77.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.fee60c77.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4a923d960294146bf0e2",
    "url": "/static/js/main.8a75f613.chunk.js"
  },
  {
    "revision": "d2aa4dcc9e92c2ee2b9b",
    "url": "/static/js/runtime-main.a563111f.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);